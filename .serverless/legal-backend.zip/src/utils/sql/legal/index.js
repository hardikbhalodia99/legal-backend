const { getOrganizationByOrganizationId } = require("./organization");
const { getLegalDB, getClientModel,getEmployeeModel,getInvoiceModel,getOrderModel,getOrganizationModel,getProductModel } = require("./utils");

//utils exports
module.exports.getLegalDB = getLegalDB;
module.exports.getClientModel = getClientModel;
module.exports.getOrganizationModel = getOrganizationModel;
module.exports.getProductModel = getProductModel;
module.exports.getEmployeeModel = getEmployeeModel;
module.exports.getInvoiceModel = getInvoiceModel;
module.exports.getOrderModel = getOrderModel;


//organization exports
module.exports.getOrganizationByOrganizationId = getOrganizationByOrganizationId;